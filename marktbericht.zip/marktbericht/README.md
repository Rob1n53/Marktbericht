# Markt-Bericht für langfristiges Investieren

Jeden Werktag morgens ein Bericht per E-Mail und als Webseite (Handy und PC) – ganz ohne E-Mail-Passwort:

- **Marktklima-Ampel**: Angstindex VIX, Trend des S&P 500, Marktbreite – mit Hinweis, was das für dich heißt
- **Weltwirtschaft**: Schlagzeilen, Termine (Zinsentscheide Fed/EZB, Quartalszahlen), Börsen, Zinsen, Dollar, Gold, Öl, Branchen
- **ETFs und Aktien** mit Einstiegs-Score (0–100), Kennzahlen, Diagramm und Rückblick-Test
- **Begriffe kurz erklärt** zum Einarbeiten

Das Programm kauft nichts. Es zeigt dir Signale, du entscheidest und kaufst selbst in der Trade-Republic-App.

---

## Einrichtung auf GitHub (ca. 15 Minuten, am besten am PC)

Du brauchst **kein E-Mail-Passwort**. GitHub schickt dir den Bericht selbst als normale E-Mail
an die Adresse, mit der du dich bei GitHub anmeldest.

1. Kostenloses Konto auf <https://github.com> anlegen (mit der E-Mail-Adresse, an die die Berichte gehen sollen).
2. Oben rechts **+** → **New repository**
   - Name: `marktbericht`
   - **Public** wählen (nur dann ist die Webseite kostenlos; der Bericht enthält keine persönlichen Daten)
   - **Create repository**
3. Dateien hochladen: **uploading an existing file** anklicken und den **Inhalt** des entpackten Ordners
   `marktbericht` hineinziehen (inkl. Ordner `.github`) → **Commit changes**.
   > Der Ordner `.github` ist auf Mac/Windows manchmal versteckt. Falls er fehlt:
   > **Add file → Create new file**, als Namen `.github/workflows/bericht.yml` eintippen,
   > Inhalt der Datei `bericht.yml` hineinkopieren, **Commit changes**.
4. Webseite einschalten: **Settings → Pages → Source: GitHub Actions**.
5. E-Mail-Benachrichtigung prüfen: Profilbild oben rechts → **Settings → Notifications**.
   Unter **Watching** muss **Email** angehakt sein (ist normalerweise schon so).
6. Erster Testlauf: Reiter **Actions** → links **Markt-Bericht** → **Run workflow**.
   Nach 2–4 Minuten kommt eine E-Mail von GitHub mit dem Betreff „Markt-Tagesbericht …“.
   Sie enthält die Zusammenfassung und einen Link zur Webseite mit allen Details und Diagrammen.
   Tipp: Die Webseite auf dem Handy zum Startbildschirm hinzufügen.

Ab jetzt läuft alles automatisch Mo–Fr gegen 7:15 Uhr. GitHub startet geplante Läufe manchmal
mit etwas Verspätung; das ist normal. Alle bisherigen Berichte findest du im Reiter **Issues** (Archiv).

**Keine E-Mail bekommen?** Spam-Ordner prüfen und Absender `notifications@github.com` als sicher markieren.
Im Reiter **Actions** siehst du, ob der Lauf grün (ok) oder rot (Fehler) ist. Bei rot: Lauf anklicken
und die Fehlermeldung an Claude schicken.

## Auf dem eigenen PC (optional)

1. Python 3.10 oder neuer installieren (<https://python.org>, unter Windows „Add to PATH“ anhaken).
2. Im Ordner `marktbericht` ein Terminal öffnen:
   ```
   pip install -r requirements.txt
   python main.py --demo --open          # Test mit simulierten Daten
   python main.py --open                 # echter Bericht im Browser
   ```

---

## Einstellungen (`config.json`)

| Eintrag | Bedeutung |
|---|---|
| `modus` | `"taeglich"` oder `"woechentlich"`. Wöchentlich: E-Mail nur am `wochentag_fuer_wochenbericht` (0 = Mo … 4 = Fr), die Webseite wird trotzdem täglich aktualisiert |
| `signal_schwelle` | ab welchem Score ein Wert unter „Heute auffällig“ erscheint (Standard 60) |
| `etfs` | ETFs mit Xetra-Kürzel (Endung `.DE`) |
| `aktien` | Aktien mit US-Kürzel (z. B. `META`); Kurs wird in Euro umgerechnet |
| `termine` | wichtige Termine, die du ergänzen kannst |
| `nachrichten` | RSS-Quellen für die Schlagzeilen |

**Neue Aktie hinzufügen**, z. B. Broadcom: in `aktien` eine Zeile `{"ticker": "AVGO", "name": "Broadcom"},` ergänzen.
Auf GitHub: Datei anklicken → Stift-Symbol → ändern → **Commit changes**.

**Kürzel finden**: auf <https://finance.yahoo.com> nach Name oder ISIN suchen. Für ETFs die Variante mit `.DE` (Xetra) nehmen.
Ob ein Wert bei Trade Republic handelbar ist, siehst du über die Suche in der App.

## So entsteht der Score

**Kursbild (0–100)** – fünf Bausteine:

| Baustein | Punkte | volle Punkte, wenn … (ETF / Aktie) |
|---|---|---|
| Abstand zum Hoch | 30 | ≥ 20 % / ≥ 35 % unter dem Allzeithoch |
| 200-Tage-Linie | 20 | ≥ 10 % / ≥ 15 % darunter |
| Wochen-RSI | 20 | RSI ≤ 30 (überverkauft) |
| 5-Jahres-Trend | 20 | ≥ 2 Standardabweichungen unter dem eigenen Trend |
| Stabilisierung | 10 | Rücksetzer ≥ 5 % **und** Kurs wieder über der 20-Tage-Linie |

**Aktien** zusätzlich: Kursbild zählt 80 %, dazu bis 20 Punkte Bewertung
(erwartetes KGV, Analysten-Kursziel, Gewinnwachstum).

Einstufung: ≥ 70 sehr guter Moment · ≥ 50 guter Moment · ≥ 25 neutral · darunter eher teuer.

**Rückblick-Test**: prüft für jeden Wert, ob Käufe bei hohem Score in der Vergangenheit besser waren als
an beliebigen Tagen, und vergleicht einen reinen Sparplan mit „70 % Sparplan + 30 % Reserve für Signale“.
Wenn das Signal für einen Wert nichts gebracht hat, sagt der Bericht das offen.

## Wichtig

- Der Score zeigt, wie günstig etwas **im Vergleich zur eigenen Vergangenheit** ist. Er sagt nicht voraus,
  ob der Kurs steigt. Nach einem Signal kann es weiter fallen.
- Einzelaktien sind deutlich riskanter als breite ETFs. Für Anfänger bewährt: Basis über ETF-Sparplan,
  Einzelaktien nur als kleiner Anteil.
- Daten von Yahoo Finance: kostenlos, ohne Gewähr. Keine Anlageberatung.
